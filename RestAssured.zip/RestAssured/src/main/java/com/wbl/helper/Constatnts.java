package com.wbl.helper;

public interface Constatnts {
	
	String path=System.getProperty("user.dir")+"//resources/";
	
	

}
